const config = {
    username: 'root',
    password: '',
    database: 'nodejs',
    dialect: 'mysql',
    host: 'localhost',
    port: 3306 // 3306 par défaut, MAMP = 8889
  }
  
  module.exports = config